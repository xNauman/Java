package route;

import java.awt.Point;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.UUID;
import java.util.Vector;

import routeCheck.SchMovePointData;

/**
 * Contains details relating to a move request
 * 
 * @author Ben
 *
 */
public class SchRouteMoveReq {

	private Queue<SchDoublePoint> mMoveList = new LinkedList<SchDoublePoint>();
	private SchDoublePoint mReqPoint = new SchDoublePoint();
	private double mMaxLengthToNav = 3;
	private SchMovePointData mMovePointData = null;

	public void basePoints(Point pStartPoint, Point pEndPoint){
		mReqPoint = new SchDoublePoint(pStartPoint, pEndPoint);
	}

	/*public void addObstruction(SchMovePointData pItem){
		this.mMoveList.add(pItem);
	}*/

	public void setPointStart(Point pStartPoint){
		mReqPoint.setStartPoint(pStartPoint);
	}

	public boolean setPointEnd(Point pEndPoint, SchMovePointData pMovePointData, boolean pDoInternalSplit){
		mReqPoint.setEndPoint(pEndPoint);
		this.mMovePointData = pMovePointData;
		
		if (pDoInternalSplit) {
				return this.performInternalSplit();
		}
		else {
			return true; //Since just setting an object
		}
	}
	
	/**
	 * Obtains the first Double Point from the list
	 * 
	 * @return
	 */
	public SchDoublePoint getPointFirst(){
		if (this.mMoveList.isEmpty())
			return null;
		
		if (!this.isReadyForSending(false))
			return null;
		
		return this.mMoveList.peek();
	}
	
	public SchMovePointData getMovePointData(){
		return this.mMovePointData;
	}
	
	public boolean removePoint(UUID pPointUUID){
		//System.out.println("SchRouteMoveReq:REMOVEPOINT - UUID to remove = " + pPointUUID.toString());
		if (this.mMoveList.isEmpty()) {
			//System.out.println("SchRouteMoveReq:REMOVEPOINT - Is Empty");
			return false;
		}
		
		if (this.mMoveList.peek().getPointUUID()==pPointUUID){
			this.mMoveList.poll();
			//System.out.println("SchRouteMoveReq:REMOVEPOINT - Removed, was first");
			return true;
		}
		
		Iterator<SchDoublePoint> itr = this.mMoveList.iterator();
		
		
		while (itr.hasNext()){

			SchDoublePoint p = (SchDoublePoint) itr.next();
			
			if (p.getPointUUID()==pPointUUID){
				this.mMoveList.remove(p);
				//System.out.println("SchRouteMoveReq:REMOVEPOINT - Removed, OTHER");
				return true;
			}
		}
		
		//System.out.println("SchRouteMoveReq:REMOVEPOINT - NOT FOUND!");
		return false;
	}
	

	public boolean isReadyForSending(boolean ifNotReadyDoInternalSplit){
		boolean bIsReady=false;
		bIsReady = mReqPoint.isComplete() && mMoveList.size()>0;

		if (!bIsReady&&ifNotReadyDoInternalSplit){
			performInternalSplit();
			bIsReady=true;
		}

		return bIsReady;
	}
	
	public boolean hasEndPoint(){
		return (this.mReqPoint.getEndPoint()==null);
	}

	public boolean performInternalSplit(){

		if (mReqPoint.isComplete()){
			if (mReqPoint.getDistance() > mMaxLengthToNav){
				//System.out.println("************* DO SPLIT: Will be " + Math.ceil(mReqPoint.getDistance()/this.mMaxLengthToNav) + " sub components");

				if (mReqPoint.isStraightLine()){
					Vector <Double> v;
					if (mReqPoint.isStraightLineHorizontal()){
						//Horizontal Line, Y are all the same
						v = straightLineSplit(mReqPoint.getStartPoint().x, mReqPoint.getEndPoint().x, mMaxLengthToNav);

						if (v==null)
							return false;
						
						for (int i = 0;i<v.size()-1;i++){
							this.mMoveList.add(new SchDoublePoint(new Point(v.get(i).intValue(),mReqPoint.getStartPoint().y),new Point(v.get(i+1).intValue(),mReqPoint.getStartPoint().y)));
						}
					}
					else {
						//Vertical Line, X are all the same
						v = straightLineSplit(mReqPoint.getStartPoint().y, mReqPoint.getEndPoint().y, mMaxLengthToNav);

						for (int i = 0;i<v.size()-1;i++){
							this.mMoveList.add(new SchDoublePoint(new Point(mReqPoint.getStartPoint().x, v.get(i).intValue()),new Point(mReqPoint.getStartPoint().x,v.get(i+1).intValue())));
						}
						
						if (v==null)
							return false;
					}
				}
				else {
					/*
					 * CODE HERE TO SPLIT A NON-STRAIGHT LINE (for this purpose, a diagonal line is deemed as not straight)
					 */

					/* Need to split the line up into equal distances */
					Vector <Point> splitPoints = diagonalLineSplit(mReqPoint.getStartPoint(), mReqPoint.getEndPoint(), mMaxLengthToNav);
					for (int i = 0; i < splitPoints.size()-1; i++){
						Point startPoint = splitPoints.get(i);
						Point endPoint = splitPoints.get(i+1);
						this.mMoveList.add(new SchDoublePoint(startPoint, endPoint));
					}
				}

				return true;
			}
			else {
				this.mMoveList.add(mReqPoint);
				return true;
			}
		}
		else {
			return false;
		}
	}

	public void debugDumpQueue(){
		
		//Copy the existing queue, so its not destroyed	
		Queue <SchDoublePoint> copyMoveList = new LinkedList<SchDoublePoint> ();
		Iterator <SchDoublePoint> itr = this.mMoveList.iterator();
		
		while (itr.hasNext()){
			copyMoveList.add((SchDoublePoint) itr.next());
		}
		

		if (copyMoveList.size()>0){
			System.out.println("Queue List (size = " + copyMoveList.size() + ") [MAX LEN = " + mMaxLengthToNav + "]");

			while (copyMoveList.size()>0) {
				SchDoublePoint p = copyMoveList.poll();
				System.out.println("... START AT " + p.getStartPoint().toString() + " to " + p.getEndPoint().toString() + " (GUID = " + p.getPointUUID() + ")");
			}

		}
	}

	/**
	 * Used for straight lines only, given a start and ending point, will 
	 * provide a split of points based on the maximum length.
	 * 
	 * 
	 * For example, given, start = 11, end = 21, and a max length of 3, 
	 * a vector of: 11, 14, 17, 20 and 21 will be returned.
	 * 
	 * @param startVal Starting Value (single co-ordinate only)
	 * @param endValue Ending Value (single co-ordinate only)
	 * @param maxLength Maximum length for a single line segment
	 * @return Split points
	 */
	private Vector<Double> straightLineSplit(double pStartValue, double pEndValue, double maxLength){
		Vector<Double> v = new Vector<Double>();

		if (pStartValue > pEndValue)
			return null;

		double lengthCountDown = pEndValue-pStartValue;

		if (lengthCountDown<=maxLength){
			v.add(pStartValue);
			v.add(pEndValue);
		}
		else {

			v.add(pStartValue);

			boolean keepCount = true;
			while (keepCount) {				
				pStartValue += maxLength;

				if (pStartValue >= pEndValue){
					v.add(pEndValue);
					keepCount = false;
				}
				else {
					v.add(pStartValue);
				}
			}
		}

		return v;
	}
	
	public boolean isQueueEmpty(){
		return this.mMoveList.isEmpty();
	}
	
	
	/**
	 * Calculates the distance between two given points represented as a set of (x,y) coordinates.
	 * A set of (x,y) coordinates represents one unit of distance.
	 * 
	 * @param pStartPoint
	 * 			the coordinates of the starting point
	 * @param pEndPoint
	 * 			the coordinates of the destination point
	 * @return the units of distance between two given points as an integer value	
	 */
	/* NOTE: Added/Altered for purpose of testing the diagonal line split method, can be moved to the appropriate location after 
	 * 		 Not sure if the getDistance method is meant to be used for a diagonal line or is it? */
	public static int calculateDistance(Point pStartPoint, Point pEndPoint) {
		double vDistance = 0;
		/* Horizontal Case: Y coordinates are the same */
		if (pStartPoint.y == pEndPoint.y && pStartPoint.x != pEndPoint.x)
			vDistance = Math.abs(pStartPoint.x - pEndPoint.x);
		/* Vertical Case: X coordinates are the same */
		else if (pStartPoint.x == pEndPoint.x && pStartPoint.y != pEndPoint.y)
			vDistance = Math.abs(pStartPoint.y - pEndPoint.y);
		/* Diagonal Case: the (x,y) coordinates are different */
		else {
			int xDistance = pEndPoint.x - pStartPoint.x;
			int yDistance = pEndPoint.y - pStartPoint.y;
			/* Use the Pythagorean Theorem to calculate the diagonal distance */
			vDistance = Math.sqrt((xDistance * xDistance) + (yDistance * yDistance));
			//vDistance = Math.round(vDistance);
		}
		
		int vDistanceInt = 0;
		/* Convert double to integer */
		vDistanceInt = (int)vDistance;
		
		return vDistanceInt;
	}
	
	/**
	 * The method {@link #calculateDistance(Point, Point)} is used to calculate the distance of the given
	 * diagonal line. This is then used to obtain the number of split segments for the diagonal line.
	 * The method {@link #calculateSplitPointsYMXB(Point, Point, double)} is then used to obtain the
	 * start and ending points for each split segment in the diagonal line.
	 * 
	 * @param pStartPoint
	 * 				the start point of the diagonal line path.
	 * @param pEndPoint
	 * 				the ending point of the diagonal line path.
	 * @param maxLength 
	 * 				maximum length of each split segment of a single line.
	 * @return a vector containing all the points for each split segment for a given line.
	 */
	public static Vector<Point> diagonalLineSplit(Point pStartPoint, Point pEndPoint, double maxLength) {
		Vector<Point> tempSplitPoints = new Vector<Point>();
		int totalLineDistance = calculateDistance(pStartPoint, pEndPoint);
		System.out.println("totalLineDistance is: " + totalLineDistance);
		double noOfSplits = (totalLineDistance/maxLength); // need double to get a more accurate result
		System.out.println("noOfSplits is: " + noOfSplits);
		
		// each split is even except for the last (which is smaller) -- easy way but don't think it always works
		//tempSplitPoints = calculateSplitPointsOLD(pStartPoint, pEndPoint, noOfSplits);
		
		tempSplitPoints = calculateSplitPoints(pStartPoint, pEndPoint, noOfSplits);
		
		return tempSplitPoints;
	}
	
	/**
	 * Uses formula for straight line (y = mx + b) to calculate the corresponding y coordinates for each x coordinate.
	 * To obtain the x coordinates we divide the distance between the start and end x coordinates by the number of
	 * split segments required.
	 * 
	 * @param pStartPoint
	 * 				the start point of the diagonal line path.
	 * @param pEndPoint
	 * 				the end point of the diagonal line path.
	 * @param pNoOfSplits
	 * 				the total number of split segments which are needed for the diagonal line (not rounded)
	 * @return a vector containing all the split points for each split segment which lie between the start and end point
	 */
	public static Vector <Point> calculateSplitPoints(Point pStartPoint, Point pEndPoint, double pNoOfSplits) {
		Vector<Point> splitPoints = new Vector<Point>();
		// Value to add to get the x coordinate for each split point
		int splitPointX = (int) (Math.abs(pStartPoint.x - pEndPoint.x) / (pNoOfSplits));
		//System.out.println("splitPointX is: " + splitPointX);
		int currentSplitX = pStartPoint.x;
		int currentSplitY = pStartPoint.y;
		//System.out.println("currentSplitX is: " + pStartPoint.x);
		//System.out.println("currentSplitY is: " + pStartPoint.y);
		
		/* // problem does not always work for the last few split segments
		for (int i = 0; i < pNoOfSplits; i++) {
			currentSplitY = routeCheck.SchRouteChecker.calculateY(pStartPoint, pEndPoint, currentSplitX);
			Point currentSplitPoint = new Point(currentSplitX, currentSplitY);
			splitPoints.add(currentSplitPoint);
			
			if (pStartPoint.x < pEndPoint.x) { // if going --> direction
				currentSplitX = currentSplitX + splitPointX;
			}
			else {
				currentSplitX = currentSplitX - splitPointX;
			}
		}
		splitPoints.add(pEndPoint); // add the initial end point to get the end point for the last split segment
		*/
		
		
		boolean exitLoop = true;
		if (pStartPoint.x < pEndPoint.x) { // if going --> direction
			//System.out.println("<--");
			while (exitLoop == true) {
				currentSplitY = routeCheck.SchRouteChecker.calculateY(pStartPoint, pEndPoint, currentSplitX);
				Point currentSplitPoint = new Point(currentSplitX, currentSplitY);
				splitPoints.add(currentSplitPoint);
				
				currentSplitX = currentSplitX + splitPointX;
				// determine if we are at the last split segment
				if (currentSplitX >= pEndPoint.x) {
					//System.out.println("currentSplitX is: " + currentSplitX);
					//System.out.println("pEndPointX is: " + pEndPoint.x);
					exitLoop = false;
				}
			}

		}//331 and 158
		else { // if going <-- direction
			//System.out.println("-->");
			while (exitLoop == true) {
				currentSplitY = routeCheck.SchRouteChecker.calculateY(pStartPoint, pEndPoint, currentSplitX);
				Point currentSplitPoint = new Point(currentSplitX, currentSplitY);
				splitPoints.add(currentSplitPoint);
				
				currentSplitX = currentSplitX - splitPointX;
				// determine if we are at the last split segment
				if (currentSplitX <= pEndPoint.x) {
					//System.out.println("currentSplitX is: " + currentSplitX);
					//System.out.println("pEndPointX is: " + pEndPoint.x);
					exitLoop = false;
				}
			}

		}
		splitPoints.add(pEndPoint); // add the initial end point to get the end point for the last split section 
		
		
		for (int i = 0; i < splitPoints.size()-1; i++) {
			System.out.println("-- Split Number -- " + (i+1));
			Point startPoint = splitPoints.get(i);
			System.out.println("	Split startPoint is: " + startPoint);
			Point endPoint = splitPoints.get(i+1);
			System.out.println("	Split endPoint is: " + endPoint);
			System.out.println("	Distance is: " + calculateDistance(startPoint, endPoint));
		}
		
		
		return splitPoints;
	}
	
	/* Similar to method above but uses a different approach. May not be used */
	public static Vector <Point> calculateSplitPointsOLD(Point pStartPoint, Point pEndPoint, double pNoOfSplits) {
		Vector<Point> splitPoints = new Vector<Point>();
		// x,y values to add to each consecutive split point
		int splitPointX = (int) (Math.abs(pStartPoint.x - pEndPoint.x) / pNoOfSplits);
		int splitPointY = (int) (Math.abs(pStartPoint.y - pEndPoint.y) / pNoOfSplits);
		//int splitPointX = (pStartPoint.x + pEndPoint.x) / pNoOfSplits;
		//int splitPointY = (pStartPoint.x + pEndPoint.x) / pNoOfSplits;
		System.out.println("splitPointX is: " + splitPointX);
		System.out.println("splitPointY is: " + splitPointY);
		// The initial start point is the start point for the first split section
		int currentSplitX = pStartPoint.x;
		int currentSplitY = pStartPoint.y;

		for (int i = 0; i < pNoOfSplits; i++) {
			Point currentSplitPoint = new Point(currentSplitX, currentSplitY);
			splitPoints.add(currentSplitPoint);
			// update x,y values to get next split point
			if (pStartPoint.x < pEndPoint.x) { // if going --> direction
				currentSplitX = currentSplitX + splitPointX;
				currentSplitY = currentSplitY + splitPointY;
			}
			else {
				currentSplitX = currentSplitX - splitPointX;
				currentSplitY = currentSplitY - splitPointY;
			}

		}
		splitPoints.add(pEndPoint); // add the initial end point to get the end point for the last split section
		
		for (int i = 0; i < splitPoints.size(); i++) {
			System.out.println("Split Point is: " + splitPoints.get(i));
		}
		
		return splitPoints;
	}

	/* Probably won't be needed */
	public static Point calculateMidPoint(Point pStartPoint, Point pEndPoint) {
		int midPointX = (pStartPoint.x + pEndPoint.x) / 2;
		int midPointY = (pStartPoint.y + pEndPoint.y) / 2;
		Point midPoint = new Point(midPointX, midPointY);
		System.out.println("MidPoint is: " + midPoint);
		
		return midPoint;
	}
	
	
	public static void main(String[] args) {
		//calculateMidPoint(new Point(1, 5), new Point(6, 19));

		//diagonalLineSplit(new Point(15, 10), new Point(154, 231), 38);
		//diagonalLineSplit(new Point(154, 231), new Point(15, 10), 38);
		diagonalLineSplit(new Point(331, 162), new Point(158, 52), 15);
		diagonalLineSplit(new Point(158, 52), new Point(331, 162), 15);
	}
	
}
