package rawobjects;
public class ROUTE_POINT implements java.io.Serializable{

	private static final long serialVersionUID = 224428767344837859L;
	private int RouteDefID;
	private int RouteID;
	private int SeqOrder;
	private int PointX;
	private int PointY;
	public ROUTE_POINT(){
		RouteDefID=0;
		RouteID =0;
		SeqOrder=0;
		PointX = 0;
		PointY = 0;
	}
	public ROUTE_POINT(int DefID,int ID,int SeqOrder,int PointX,int PointY){
		this.RouteDefID = DefID;
		this.RouteID = ID;
		this.SeqOrder = SeqOrder;
		this.PointX = PointX;
		this.PointY = PointY;
	}
	public int getRouteDefID(){
		return RouteDefID;
	}

	public int getRouteID(){
		return RouteID;
	}
	public int getSeqOrder(){
		return SeqOrder;
	}

	public int getPointX(){
		return PointX;
	}

	public int getPointY(){
		return PointY;
	}

	public void setRouteDefID(int iRouteDefID){
		RouteDefID = iRouteDefID;
	}

	public void setRouteID(int iRouteID){
		RouteID = iRouteID;
	}

	public void setSeqOrder(short pSeqOrder){
		SeqOrder = pSeqOrder;
	}

	public void setPointX(int pPointX){
		PointX = pPointX;
	}

	public void setPointY(int pPointY){
		PointY = pPointY;
	}
}

