package rawobjects;

public class SYS_SIMULATOR_RUN implements java.io.Serializable{

	private static final long serialVersionUID = -1555382357673708018L;
	private int SimRunID;
	private java.sql.Date StartDate;
	private java.sql.Date EndDate;
	private int MapID;
	private boolean StartSignal;
	private boolean CMEStatus;
	private boolean TRKStatus;
	private boolean DBStatus;
	private boolean SUStatus;
	private boolean SCHStatus;
	private boolean NAVStatus;
	public SYS_SIMULATOR_RUN(){
		SimRunID =0;
		StartDate =null;
		EndDate = null;
		MapID =0;
		StartSignal = false;
		CMEStatus = false;
		TRKStatus = false;
		DBStatus = false;
		SUStatus = false;
		SCHStatus = false;
		NAVStatus = false;
	}

	public int getSimRunID(){
		return SimRunID;
	}
	public java.sql.Date getStartDate(){
		return StartDate;
	}

	public java.sql.Date getEndDate(){
		return EndDate;
	}

	public int getMapID(){
		return MapID;
	}
	public boolean getStartSignal(){
		return StartSignal;
	}

	public boolean getCMEStatus(){
		return CMEStatus;
	}
	public boolean getTRKStatus(){
		return TRKStatus;
	}

	public boolean getDBStatus(){
		return DBStatus;
	}

	public boolean getSUStatus(){
		return SUStatus;
	}

	public boolean getSCHStatus(){
		return SCHStatus;
	}

	public boolean getNAVStatus(){
		return NAVStatus;
	}

	public void setSimRunID (int pSimRunID){
		SimRunID = pSimRunID;
	}

	public void setStartDate(java.sql.Date pStartDate){
		StartDate = pStartDate;
	}

	public void setEndDate(java.sql.Date pEndDate){
		EndDate = pEndDate;
	}

	public void setMapID(int pMapID){
		MapID = pMapID;
	}

	public void setStartSignal(boolean pStart){
		StartSignal = pStart;
	}
	public void setCMEStatus(boolean pCME){
		CMEStatus = pCME;
	}
	public void setTRKStatus(boolean pTRK){
		TRKStatus = pTRK;
	}
	public void setDBStatus(boolean pDB){
		DBStatus = pDB;
	}
	public void setSUStatus(boolean pSUStatus){
		SUStatus = pSUStatus;
	}
	public void setSCHStatus(boolean pSCH){
		SCHStatus = pSCH;
	}
	public void setNAVStatus(boolean pNAV){
		NAVStatus = pNAV;
	}

}

