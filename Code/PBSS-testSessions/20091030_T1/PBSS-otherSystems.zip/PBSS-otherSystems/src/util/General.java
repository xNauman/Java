package util;

public class General {

	//location of data files: traffic lights, route configs, etc
	public static String pathDataFile()
    {
        return System.getProperty("user.dir") + "/DAT/";
    }
	
	public static String pathDataFile(String sFileName)
    {
        return pathDataFile() + sFileName;
    }
	
	public static String pathDataFileIPList()
    {
        return System.getProperty("user.dir") + "/DAT/IPs/";
    }
	
	public static String pathDataFileIPList(String sFileName)
    {
        return pathDataFileIPList() + sFileName;
    }
	
	
}
