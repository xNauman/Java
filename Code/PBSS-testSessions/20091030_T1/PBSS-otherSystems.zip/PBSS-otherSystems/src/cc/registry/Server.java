package cc.registry;

import java.io.*;
import java.net.*;

import rmi_dummy.DummyRMI_IPList;

public class Server extends Settings {

	private int activeClients;
	private int registeredClients;
	private String[] clientIP = new String[6];

	/*
	 * Modified By David Taberner
	 * Removed the need for the activeClients parameter
	 * 
	 * Broadcast code will sent out a online confirmation to a module as soon as it responds to the broadcast
	 * The reason for this is that waiting for all modules to connect before sending out the confirmation really
	 * slows the broadcast down and makes its performance unreliable.
	 * 
	 * Have left the activeClients param in the code so not to break the existing client implementations
	 * however it is no longer used.
	 * The broadcast server will continue running until it is stopped, hence it now needs to be run in its own thread. 
	 * 
	 * This improves registration time by around 80-90%
	 * It also allows for modules such as CME and setup to operate without all other modules being online (except DB) 
	 * 
	 */
	public Server(int activeClients) throws Exception {

		super();
		this.activeClients = activeClients;

		socket.joinGroup(group);
		while(!broadcast()) {
			//System.out.println("AA"); //added by Ben
			receivePacket();
			// wait for 2 seconds before next broadcast
			try { 
				Thread.sleep(2000); 
			}
			catch(InterruptedException e){}
		}
		socket.leaveGroup(group);
	}

	// SERVER (CC) TO BROADCAST LOCAL IP ADDRESS TO ALL CLIENTS IN THE GROUP
	private boolean broadcast() throws IOException {

		//System.out.println("BB"); //added by Ben

		String data;
//		if(registeredClients == activeClients) data = "ONLINE";
//		else data = "CC";

		data = "CC";
		
		byte[] buf = data.getBytes();
		// broadcast across the network
		DatagramPacket packet = new DatagramPacket(buf, buf.length, group, port);
		socket.send(packet);
		
		data = "ONLINE";
		
		buf = data.getBytes();
		// broadcast across the network
		packet = new DatagramPacket(buf, buf.length, group, port);
		socket.send(packet);
		
		receivePacket();

		// all clients registered
//		if(data.equals("ONLINE")) return true;

		return false;
	}

	// RECEIVE INCOMING PACKET
	private void receivePacket() throws IOException {

		byte[] buf = new byte[6];

		DatagramPacket packet = new DatagramPacket(buf, buf.length);
		// note: method gets blocked here if no packet to receive
		socket.receive(packet);

		// extract IP address from packet
		InetAddress IP = packet.getAddress();
		String data = new String(packet.getData()).trim();
		
		//////////////////////////// SYDNEY Test Code
		DummyRMI_IPList.saveIP(new String(packet.getData()).trim(),IP.getHostAddress().toString());
		////////////////////////////

		// send acknowledgement back to client
		if(data.equals("CME"))      sendAck(data, IP);
		else if(data.equals("DB"))  sendAck(data, IP);
		else if(data.equals("NAV")) sendAck(data, IP);
		else if(data.equals("SCH")) sendAck(data, IP);
		else if(data.equals("SU"))  sendAck(data, IP);
		else if(data.equals("TKR")) sendAck(data, IP);
	}

	// SEND ACKNOWLEDGEMENT (IN LOWER CASE) DIRECTLY BACK TO CLIENT
	private void sendAck(String ID, InetAddress IP) throws IOException {

		byte[] buf = ID.toLowerCase().getBytes();
		socket.send(new DatagramPacket(buf, buf.length, IP, port));
		saveIP(ID, IP);
	}

	// SAVE IP ADDRESS RECEIVED FROM SPECIFIED CLIENT
	private void saveIP(String ID, InetAddress IP) {

		if(clientIP[getIndex(ID)]==null) {
			clientIP[getIndex(ID)] = IP.getHostAddress();
			registeredClients++;        // increment no. of registered clients
		}
	}

	// METHOD TO GET INDEX OF SPECIFIED SUBSYSTEM
	private int getIndex(String ID) {

		if(ID.equals("CME")) return 0;
		if(ID.equals("DB"))  return 1;
		if(ID.equals("NAV")) return 2;
		if(ID.equals("SCH")) return 3;
		if(ID.equals("SU"))  return 4;
		if(ID.equals("TKR")) return 5;
		return -1;
	}

	// GET METHOD TO EXTERNALLY RETRIEVE CLIENT IP ADDRESS
	public String getClientIP(String ID) {

		if(ID.equals("CME")) return clientIP[0];
		if(ID.equals("DB"))  return clientIP[1];
		if(ID.equals("NAV")) return clientIP[2];
		if(ID.equals("SCH")) return clientIP[3];
		if(ID.equals("SU"))  return clientIP[4];
		if(ID.equals("TKR")) return clientIP[5];
		return null;
	}
}