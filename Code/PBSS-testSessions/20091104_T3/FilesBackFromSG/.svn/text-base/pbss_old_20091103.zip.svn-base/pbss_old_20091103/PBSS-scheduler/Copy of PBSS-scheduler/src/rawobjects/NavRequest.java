package rawobjects;

public class NavRequest implements java.io.Serializable {
	
	private static final long serialVersionUID = 1740600634581485813L;
	
	private Bus bBus;
	private int iMovementStartTime;
	private int iMovementEndTime;
	
	public NavRequest(int pMovementStartTime, int pMovementEndTime, Bus pBus)
	{
		this.bBus = pBus;
		this.iMovementStartTime = pMovementStartTime;
		this.iMovementEndTime = pMovementEndTime;
		
	}


	public Bus getbBus() {
		return bBus;
	}

	public void setbBus(Bus bBus) {
		this.bBus = bBus;
	}

	public int getiMovementStartTime() {
		return iMovementStartTime;
	}

	public void setiMovementStartTime(int iMovementStartTime) {
		this.iMovementStartTime = iMovementStartTime;
	}

	public int getiMovementEndTime() {
		return iMovementEndTime;
	}

	public void setiMovementEndTime(int iMovementEndTime) {
		this.iMovementEndTime = iMovementEndTime;
	}
	

}
