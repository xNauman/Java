package routeCheck;

public enum SchEnumSplitLoc {
	NO_SPLIT,
	SPLIT_BEFORE,
	SPLIT_AFTER
}
