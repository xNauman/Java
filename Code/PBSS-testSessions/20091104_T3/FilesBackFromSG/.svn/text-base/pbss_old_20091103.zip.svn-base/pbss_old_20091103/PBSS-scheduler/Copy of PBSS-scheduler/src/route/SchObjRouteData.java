package route;

public class SchObjRouteData {
	//JUNK?
}
