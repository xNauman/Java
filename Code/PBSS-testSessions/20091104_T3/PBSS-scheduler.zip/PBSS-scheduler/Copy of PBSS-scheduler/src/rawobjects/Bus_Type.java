package rawobjects;
import java.awt.image.*;
public class Bus_Type implements java.io.Serializable{
    private static final long serialVersionUID = -4592712066939011000L;
    private int BusTypeID;
    private String BusType;
    private int BusColour;    
    private int MaxCapacity;
    private int[] BusImage;
    private int Bt_Width;
    private int Bt_Height;
    public Bus_Type(){
        this.BusTypeID=0;
        this.BusType=null;
        this.BusColour=-1;
        this.Bt_Height=0;
        this.Bt_Width=0;
        this.MaxCapacity=0;
        this.BusImage=null;
    }
    public Bus_Type(int TypeID,String Type,int Colour,int Capacity,BufferedImage Image,int width,int height){
        this.BusTypeID =TypeID;
        this.BusType = Type;
        this.BusColour = Colour;
        this.MaxCapacity = Capacity;
        this.BusImage = ImageSerializer.serialiseBufferedImage(Image);
        this.Bt_Width = width;
        this.Bt_Height = height;
    }
    public int getBt_Width(){
        return Bt_Width;
    }
    public void setBt_Width(int pBusTypeWidth){
        this.Bt_Width = pBusTypeWidth;
    }
    public int getBt_Height(){
        return Bt_Height;
    }
    public void setBt_Height(int pBusTypeHeight){
        this.Bt_Height = pBusTypeHeight;
    }
    public int getBusTypeID(){
        return BusTypeID;
    }
    
    public void setBusTypeID(int pBusTypeID){
        BusTypeID = pBusTypeID;
    }
    
    public String getBusType(){
        return BusType;
    }
    
    public void setBusType (String pBusType){
        BusType = pBusType;
    } 
    
    public int getBusColour(){
        return BusColour;
    }
    
    public void setBusColour(int pBusColour){
        BusColour = pBusColour;
    }
    
    public int getMaxCapacity(){
        return MaxCapacity;
    }
    
    public void setMaxCapacity(short pMaxCapacity){
        MaxCapacity = pMaxCapacity;
    }
    
    public BufferedImage getBusImage(){
        return ImageSerializer.intArrayToBufferedImage(BusImage, Bt_Width, Bt_Height);
    }
    
    public void setBusImage(BufferedImage pBusImage){
        BusImage = ImageSerializer.serialiseBufferedImage(pBusImage);
    }

}
