package rmi_engine;

public enum SCHRMICmdType {
	UNKNOWN,
	SCH_PRESTART,
	SCH_START,
	SCH_STOP
}
