package rawobjectsPriv;

public class NetIPInfo {
	private String mIPAddress;
	private int mPort;
	private String mRMIName;
	private String mSetBy;

	public NetIPInfo(){
		this.mIPAddress = "0.0.0.0";
		this.mPort = -1;
		this.mRMIName = "";
		this.mSetBy = "";
	}

	public NetIPInfo(String pIPAddress, int pPort, String pRMIName, String pSetBy){
		this.mIPAddress = pIPAddress;
		this.mPort = pPort;
		this.mRMIName = pRMIName;
		this.mSetBy = pSetBy;
	}

	public String getIPAddress() {
		return mIPAddress;
	}
	public void setIPAddress(String pIPAddress, String pSetBy) {
		this.mIPAddress = pIPAddress;
		this.mSetBy = pSetBy; 
	}

	public int getPort() {
		return mPort;
	}
	public void setPort(int pPort, String pSetBy) {
		this.mPort = pPort;
		this.mSetBy = pSetBy;
	}

	public String getRMIName() {
		return mRMIName;
	}

	public void setRMIName(String pRMIName, String pSetBy) {
		this.mRMIName = pRMIName;
		this.mSetBy = pSetBy;
	}

	public String getSetBy(){
		return mSetBy;
	}

	public void setSetBy(String pSetBy){
		this.mSetBy = pSetBy;
	}



}
