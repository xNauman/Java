package junit;


import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class RAWOBJ_ROUTE_POINT {
	
	rawobjects.ROUTE_POINT mROUTEPOINT = new rawobjects.ROUTE_POINT();
	
	@Test
	public void getRouteDefIDTest(){
		mROUTEPOINT.setRouteDefID(12);
		
		assertEquals(12,mROUTEPOINT.getRouteDefID());
	}

	
	@Test
	public void getRouteIDTest(){
		mROUTEPOINT.setRouteID(1);
		
		assertEquals(1,mROUTEPOINT.getRouteID());
	}
	
	@Test
	public void getSeqOrderTest(){
		mROUTEPOINT.setSeqOrder((short) 100);
		
		assertEquals(100,mROUTEPOINT.getSeqOrder());
	}
	
	@Test
	public void getPointXTest(){
		mROUTEPOINT.setPointX(34);
		
		assertEquals(34,mROUTEPOINT.getPointX());
	}
	

	@Test
	public void getPointYTest(){
		mROUTEPOINT.setPointY(64);
		
		assertEquals(64,mROUTEPOINT.getPointY());
	}

}
