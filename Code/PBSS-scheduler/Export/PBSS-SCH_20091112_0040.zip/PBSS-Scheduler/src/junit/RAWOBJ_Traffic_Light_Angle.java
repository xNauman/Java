package junit;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class RAWOBJ_Traffic_Light_Angle {
	
	rawobjects.Traffic_Light_Angle mTrafficLightAngle = new rawobjects.Traffic_Light_Angle();
	
	@Test
	public void getAngleIDTest(){
		mTrafficLightAngle.setAngleID(12);
		
		assertEquals(12,mTrafficLightAngle.getAngleID());
	}
	
	@Test
	public void getTrafficLightIDTest(){
		mTrafficLightAngle.setTrafficLightID(10);
		
		assertEquals(10,mTrafficLightAngle.getTrafficLightID());
	}
	
	@Test
	public void getDirectionTest(){
		mTrafficLightAngle.setDirection(110);
		
		assertEquals(110,mTrafficLightAngle.getDirection());
	}
	
	/*@Test
	public void getAngleTest(){
		mTrafficLightAngle.setAngle((double)77.9);
		
		assertEquals(77.9,mTrafficLightAngle.getAngle());
	}*/
    
}
