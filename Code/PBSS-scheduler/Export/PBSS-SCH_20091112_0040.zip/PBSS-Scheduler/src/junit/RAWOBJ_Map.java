package junit;

public class RAWOBJ_Map {
	
	//rawobjects.Map mMap = new rawobjects.Map();

}
