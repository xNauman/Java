package junit;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class RAWOBJ_Pax_Stat {
	
	rawobjects.Pax_Stat mPaxStat = new rawobjects.Pax_Stat();
	
	@Test
	public void getPaxStatIDTest(){
		mPaxStat.setPaxStatID(12);
		
		assertEquals(12,mPaxStat.getPaxStatID());
	}
	@Test
	public void getSimRunIDTest(){
		mPaxStat.setSimRunID(2);
		
		assertEquals(2,mPaxStat.getSimRunID());
	}
	
	@Test
	public void getBusStopIDTest(){
		mPaxStat.setBusStopID(1);
		
		assertEquals(1,mPaxStat.getBusStopID());
	}
	
	@Test
	public void getCountTest(){
		mPaxStat.setCount(20);
		
		assertEquals(20,mPaxStat.getCount());
	}
	
	@Test
	public void getBusIDTest(){
		mPaxStat.setBusID(13);
		
		assertEquals(13,mPaxStat.getBusID());
	}
	
}
