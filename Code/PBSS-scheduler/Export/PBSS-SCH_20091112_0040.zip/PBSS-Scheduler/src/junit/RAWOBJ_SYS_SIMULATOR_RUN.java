package junit;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class RAWOBJ_SYS_SIMULATOR_RUN {
	
	rawobjects.SYS_SIMULATOR_RUN mSYSSIMULATORRUN = new rawobjects.SYS_SIMULATOR_RUN();
	
	
	@Test
	public void getSimRunIDTest(){
		mSYSSIMULATORRUN.setSimRunID(3);
		
		assertEquals(3,mSYSSIMULATORRUN.getSimRunID());
	}
	
	/*public java.sql.Timestamp getStartDate(){
    return StartDate;
	}

	public java.sql.Timestamp getEndDate(){
    return EndDate;
	}*/
	
	@Test
	public void getMapIDTest(){
		mSYSSIMULATORRUN.setMapID(10);
		
		assertEquals(10,mSYSSIMULATORRUN.getMapID());
	}
	
	@Test
	public void getStartSignalTest(){
		mSYSSIMULATORRUN.setStartSignal(true);
		
		assertEquals(true,mSYSSIMULATORRUN.getStartSignal());
	}
	
	@Test
	public void getCMEStatusTest(){
		mSYSSIMULATORRUN.setCMEStatus(false);
		
		assertEquals(false,mSYSSIMULATORRUN.getCMEStatus());
	}
	
	@Test
	public void getTRKStatusTest(){
		mSYSSIMULATORRUN.setTRKStatus(true);
		
		assertEquals(true,mSYSSIMULATORRUN.getTRKStatus());
	}
	
	@Test
	public void getDBStatusTest(){
		mSYSSIMULATORRUN.setDBStatus(false);
		
		assertEquals(false,mSYSSIMULATORRUN.getDBStatus());
	}
	
	@Test
	public void getSUStatusTest(){
		mSYSSIMULATORRUN.setSUStatus(false);
		
		assertEquals(false,mSYSSIMULATORRUN.getSUStatus());
	}
	
	@Test
	public void getSCHStatusTest(){
		mSYSSIMULATORRUN.setSCHStatus(true);
		
		assertEquals(true,mSYSSIMULATORRUN.getSCHStatus());
	}
	
	@Test
	public void getNAVStatusTest(){
		mSYSSIMULATORRUN.setNAVStatus(true);
		
		assertEquals(true,mSYSSIMULATORRUN.getNAVStatus());
	}
	
	



}
