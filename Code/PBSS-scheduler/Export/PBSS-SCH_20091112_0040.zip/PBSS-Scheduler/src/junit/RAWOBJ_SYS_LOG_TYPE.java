package junit;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class RAWOBJ_SYS_LOG_TYPE {
	
	rawobjects.SYS_LOG_TYPE mSYSLOGTYPE = new rawobjects.SYS_LOG_TYPE();
	
	@Test
	public void getEventTypeIDTest(){
		mSYSLOGTYPE.setEventTypeID((short) 100);
		
		assertEquals(100,mSYSLOGTYPE.getEventTypeID());
	}
	
	@Test
	public void getEventTypeTest(){
		mSYSLOGTYPE.setEventType("EventType");
		
		assertEquals("EventType",mSYSLOGTYPE.getEventType());
	}



}
