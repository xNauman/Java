package junit;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class RAWOBJ_Sys_Setting {
	
	rawobjects.Sys_Setting mSysSetting = new rawobjects.Sys_Setting();
	
	@Test
	public void getName_SettingTest(){
		mSysSetting.setName_Setting("Set");
		
		assertEquals("Set",mSysSetting.getName_Setting());
	}
	
	@Test
	public void getValue_SettingTest(){
		mSysSetting.setValue_Setting("B");
		
		assertEquals("B",mSysSetting.getValue_Setting());
	}
	
	@Test
	public void getDesc_SettingTest(){
		mSysSetting.setDesc_Setting("F");
		
		assertEquals("F",mSysSetting.getDesc_Setting());
	}
	
	@Test
	public void getCreatedByTest(){
		mSysSetting.setCreateBy("Name");
		
		assertEquals("Name",mSysSetting.getCreatedBy());
	}
	

    /*public java.sql.Date getCreatedDate() {
        return CreatedDate;
    }

    public void setCreatedDate(java.sql.Date pCreateDate) {
        CreatedDate = pCreateDate;
    }*/
	
	@Test
	public void getModifiedByTest(){
		mSysSetting.setModifiedBy("Na");
		
		assertEquals("Na",mSysSetting.getModifiedBy());
	}
	


	/*
    public java.sql.Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(java.sql.Date pDateModified) {
        ModifiedDate = pDateModified;
    }*/

}
