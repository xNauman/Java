package junit;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class RAWOBJ_Building {
	
	rawobjects.Building mBuilding = new rawobjects.Building(1, 2, 4, 2, 200, 400);
	
	@Test
	public void getBuildingIDTest(){
		mBuilding.setBuildingID(1);
		
		assertEquals(1,mBuilding.getBuildingID());
	}
	
	@Test
	public void getMapIDTest(){
		mBuilding.setMapID(2);
		
		assertEquals(2,mBuilding.getMapID());
	}
}
