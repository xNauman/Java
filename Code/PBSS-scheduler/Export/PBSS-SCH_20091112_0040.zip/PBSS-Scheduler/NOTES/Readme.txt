To Start SCHEDULER:

	1. Run mainCall.schMainCall
	2. Enter command "run":
		RUN starts:
			a. Broadcast Service
			b. Local RMI Server
			c. Time Control

	3. To check if modules have registered: use "comms.info"

	4. To FORCE a prestart: "p.f" and follow instructions
	5. to FORCE a start: ENSURE prestart is complete, then "s.f" 




DEBUG NOTES:

	* Check that config.SysConfig mUseDummyRMIService (~line 65) is set to FALSE when used in Prodn
	
	* Max Length to NAV is in SchRouteMoveReq, mMaxLengthToNav (~line 22)