import cc.registry.*;

public class client {

    public static void main(String[] args) throws Exception {
        // specify string as CME, DB, NAV, SCH, SU, TKR
        Client c = new Client("NAV");
        System.out.println(c.getServerIP());
    }
}